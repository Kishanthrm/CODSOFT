import React from 'react'

const EditProfileDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default EditProfileDetails
