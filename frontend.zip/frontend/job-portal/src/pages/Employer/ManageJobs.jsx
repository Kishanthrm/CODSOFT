import React from 'react'

const ManageJobs = () => {
  return (
    <div>
      
    </div>
  )
}

export default ManageJobs
