import React from 'react'

const JobPostingForm = () => {
  return (
    <div>
      JobPostingForm
    </div>
  )
}

export default JobPostingForm
