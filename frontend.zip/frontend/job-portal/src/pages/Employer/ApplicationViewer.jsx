import React from 'react'

const ApplicationViewer = () => {
  return (
    <div>
      
    </div>
  )
}

export default ApplicationViewer
