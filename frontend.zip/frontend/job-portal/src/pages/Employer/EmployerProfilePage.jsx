import React from 'react'

const EmployerProfilePage = () => {
  return (
    <div>
      
    </div>
  )
}

export default EmployerProfilePage
