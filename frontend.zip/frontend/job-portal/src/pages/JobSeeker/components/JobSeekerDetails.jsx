import React from 'react'

const JobSeekerDetails = () => {
  return (
    <div>
      JobSeekerDetails
    </div>
  )
}

export default JobSeekerDetails
