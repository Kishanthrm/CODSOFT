import React from 'react'

const JobDetails = () => {
  return (
    <div>
      JobDetails
    </div>
  )
}

export default JobDetails
