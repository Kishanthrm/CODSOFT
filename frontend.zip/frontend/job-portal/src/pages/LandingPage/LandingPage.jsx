import React from 'react'
import Header from './components/Header'

const LandingPage = () => {
  return (
    <div className='min-h-screen'>
     <Header />
    </div>
  )
}

export default LandingPage
